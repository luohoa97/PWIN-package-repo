IN ORDER TO respect dd's license (GPL) I've decided to add a link to DD's source code here:


https://github.com/coreutils/coreutils/blob/master/src/dd.c


This is also here to help users find the source code!